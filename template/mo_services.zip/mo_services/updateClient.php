<?php
//http://stackoverflow.com/questions/18382740/cors-not-working-php
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin:{$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:{$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }

    //http://stackoverflow.com/questions/15485354/angular-http-post-to-php-and-undefined
    $postdata = file_get_contents("php://input");
    if (isset($postdata)) {

        $request = json_decode($postdata);
        $id = $request->post_id;
        $nom = $request->post_nom;
        $prenom = $request->post_prenom;
        $email = $request->post_email;
        $phone = $request->post_phone;

        require_once ('../wp-config.php');
        global $wpdb;

        //avec file_get_contents
        $q = $wpdb->update( 
            'ido_clients', 
            array( 
                'nom' => $nom,
                'prenom' => $prenom,
                'email' => $email,
                'phone'  => $phone
            ), 
            array( 
                'id' => $id
            ) 
        );

        if($q) {
            echo "success";
        }

    }else{
        die();
    }
?>