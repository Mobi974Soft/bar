<?php
//http://stackoverflow.com/questions/18382740/cors-not-working-php
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin:{$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:{$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }

    //http://stackoverflow.com/questions/15485354/angular-http-post-to-php-and-undefined
    $postdata = file_get_contents("php://input");
    if (isset($postdata)) {

        $request = json_decode($postdata);
        $plaqueId = $request->post_plaqueId;
        $clientId = $request->post_clientId;
        $marque = $request->post_marque;
        $modele = $request->post_modele;
        $type = $request->post_type;

        require_once ('../wp-config.php');
        //require_once(ABSPATH . 'wp-admin/includes/image.php');
        global $wpdb;

        //avec file_get_contents

        $q = $wpdb->insert( 
            'ido_voitures', 
            array( 
                'plaqueId' => $plaqueId,
                'clientId' => $clientId,
                'marque' => $marque,
                'modele' => $modele,
                'type' => $type
            ), 
            array( 
                '%s',
                '%d',
                '%s',
                '%s',
                '%s'
            ) 
        );

        if ($q != false) {
            echo $wpdb->insert_id;
        }else{
            echo 0;
        }

        //$post_id = wp_insert_post($post_data);

        //echo $post_id;

    }else{
        die();
    }
?>