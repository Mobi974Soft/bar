<?php
//http://stackoverflow.com/questions/18382740/cors-not-working-php
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin:{$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:{$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }

    //http://stackoverflow.com/questions/15485354/angular-http-post-to-php-and-undefined
    $postdata = file_get_contents("php://input");
    if (isset($postdata)) {

        $request = json_decode($postdata);
        $lavageId = $request->post_lavageId;
        $voitureId = $request->post_voitureId;
        $plaqueId = $request->post_plaqueId;
        $img = $request->post_img;
        $date = date("dmY");

        require_once ('../wp-config.php');
        //require_once(ABSPATH . 'wp-admin/includes/image.php');
        global $wpdb;

        //avec file_get_contents

        
        

        $uploadDir = "/var/www/html/sites_clients/idocars/mo_services/etatDesLieux/";
        $uploadDir2 = "/mo_services/etatDesLieux/";
        $img = str_replace('data:image/png;base64,', '', $img);
        $img = str_replace(' ', '+', $img);
        $data = base64_decode($img);
        $file = $uploadDir.$plaqueId.'_'.$date.'.png';
        $path = $uploadDir2.$plaqueId.'_'.$date.'.png';

        $success = file_put_contents($file, $data);

        if ($success != false) {
            
            $q = $wpdb->insert( 
                'ido_etat_des_lieux', 
                array(
                    'lavageId' => $lavageId,
                    'voitureId' => $voitureId,
                    'imgUrl' => $path
                ), 
                array(
                    '%d',
                    '%d',
                    '%s'
                ) 
            );

            if ($q != false) {
                echo $wpdb->insert_id;
            }else{
                echo 0;
            }

        }else{
            echo 0;
        }

    }else{
        die();
    }
?>