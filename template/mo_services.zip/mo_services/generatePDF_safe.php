<?php
//http://stackoverflow.com/questions/18382740/cors-not-working-php
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin:{$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:{$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }

    //http://stackoverflow.com/questions/15485354/angular-http-post-to-php-and-undefined
    $postdata = file_get_contents("php://input");
    if (isset($postdata)) {

        $request = json_decode($postdata);
        $clientId = $request->post_clientId;
        $lavageId = $request->post_lavageId;
        $imgSignature = $request->post_img;
        if ($request->post_imgEDL) {
            $imgEDL = $request->post_imgEDL;
        }else{
            $imgEDL = "";
        }
        if ($request->post_remise) {
            $remise = $request->post_remise;
        }else{
            $remise = 0;
        }
        

        require_once ('../wp-config.php');
        global $wpdb;

        /*$uploadDir = "/var/www/html/sites_clients/idocars/mo_services/etatDesLieux/";
        $uploadDir2 = "/mo_services/etatDesLieux/";*/
        /*$img = str_replace('data:image/png;base64,', '', $img);
        $img = str_replace(' ', '+', $img);
        $dataSignature = base64_decode($img);*/
        /*$file = $uploadDir.$plaqueId.'_'.$date.'.png';
        $path = $uploadDir2.$plaqueId.'_'.$date.'.png';

        $success = file_put_contents($file, $data);*/

        /*
        if ($success != false) {

        }else{
            echo 0;
        }
        */


/*Partie recuperation des donnees*/
$r = "SELECT * FROM ido_clients WHERE id = ".$clientId;
$q = $wpdb->get_row($r);

if ($q !== null) {
    $client_email = $q->email;
    $client_nom = $q->nom;
    $client_prenom = $q->prenom;
}

$typesLavage = array();
$optionsLavage = array();
$comLavage = array();
$plaque = "";
$type = "";
$tmpTL = array();
$tmpOL = array();
$tmpTotal = array();
$total = 0;
$today = Date("d/m/Y");

$r = "SELECT a.typesLavage as typesLavage, a.optionsLavage as optionsLavage, a.commentaire as comLavage , b.plaqueId as plaqueId, b.type as type FROM ido_lavages as a JOIN ido_voitures as b ON (a.voitureId = b.id) WHERE a.id = ".$lavageId;
$q = $wpdb->get_results($r);

if (count($q)>0) {
	foreach($q as $lavage){
		$typesLavage = explode(",", $lavage->typesLavage);
        $optionsLavage = explode(",", $lavage->optionsLavage);
        $comLavage = $lavage->comLavage;
		$plaque = $lavage->plaqueId;
		$type = $lavage->type;
	}
}


/*Recuperer la liste des prix*/
/*$recup = json_decode(file_get_contents("http://167.114.244.232/sites_clients/idocars/mo_services/jsons/typesLavage.json",true));*/
$recup = json_decode(file_get_contents("jsons/typesLavage.json"));
/*var_dump($recup);
die();*/

foreach ($recup as $value) {
	if ($value->type == $type OR $value->type == "ALL" ) {
		for ($i=0; $i < count($typesLavage); $i++) {
			if ($typesLavage[$i] == $value->text) {
				array_push($tmpTL,$value);
			}
		}
	}
    if ($value->type == "OPTION") {
        for ($i=0; $i < count($optionsLavage); $i++) { 
            if ($optionsLavage[$i] == $value->text) {
                array_push($tmpOL,$value);
            }
        }
    }
}

$tmpTotal = array_merge($tmpTL,$tmpOL);
foreach ($tmpTotal as $value) {
    $total += $value->prix;
}

$hasCielDeToitDecolle = false;
/*on va retirer 20 euro sur le prix total si dans les commentaires on a ciel de toit decolle*/
/*$hasCielDeToitDecolle = strpos($lavage->comLavage, "Ciel de toit decolle");
if ($hasCielDeToitDecolle >= 0) {
    $total -= 20;
    $hasCielDeToitDecolle = true;
}*/

/*remise exceptionnelle*/
if ($remise) {
    $total -= $remise;
}

/*design de l'email*/
$display = "";

/*Page 1*/
$display .= '<img src="img/logo.png" alt="logo" width="100" height="100"/>';
$display .= '<h2 style="text-align: center;">Récapitulatif de commande</h2>';
$display .= '<h3 style="text-align: center;">'.$plaque.'</h3>';

$display .= "<br>";
$display .= "<br>";
$display .= "<br>";
$display .= "<br>";

/*body*/
$display .= "<br>";
$display .= "<h3>Types de lavages</h3>";
$display .= "<table>";
foreach ($tmpTL as $value) {
	$display .= "<tr>";
		$display .= "<td>";
		$display .= $value->text;
		$display .= "</td>";
		$display .= "<td>";
            if($value->text == 'Cquartz'){
                $display .= "Selon devis";
            }else{
                $display .= $value->prix." &euro;";
            }			
		$display .= "</td>";
	$display .= "</tr>";	
}
$display .= "</table>";
$display .= "<h3>Options de lavages</h3>";
$display .= "<table>";
foreach ($tmpOL as $value) {
    $display .= "<tr>";
        $display .= "<td>";
        $display .= $value->text;
        $display .= "</td>";
        $display .= "<td>";
            $display .= $value->prix." &euro;";
        $display .= "</td>";
    $display .= "</tr>";    
}
$display .= "</table>";
/*if ($remise != 0 || $hasCielDeToitDecolle >= 0) {*/
if ($remise != 0) {
    $display .= "<h3>Autres</h3>";
    $display .= "<table>";
        if ($remise) {
            $display .= "<tr>";
                $display .= "<td>";
                    $display .= "Remise exceptionnelle";
                $display .= "</td>";
                $display .= "<td>";
                    $display .= "-".$remise." &euro;";
                $display .= "</td>";
            $display .= "</tr>";
        }
        /*if ($hasCielDeToitDecolle >= 0) {
            $display .= "<tr>";
                $display .= "<td>";
                    $display .= "Ciel de toit dÃ©collÃ©";
                $display .= "</td>";
                $display .= "<td>";
                    $display .= "-20 &euro;";
                $display .= "</td>";
            $display .= "</tr>";
        }*/       
    $display .= "</table>";
}
$display .= "<h3>Total à payer</h3>";
$display .= "<table>";
$display .= "<tr>";
$display .= "<td>";
$display .= "</td>";
$display .= "<td>";
$display .= $total." &euro;";
$display .= "</td>";
$display .= "</tr>";
$display .= "</table>";

$display .= "<br>";
$display .= "<br>";
$display .= "<br>";
$display .= "<br>";
$display .= "<br>";
$display .= "<br>";
$display .= "<br>";
$display .= "<br>";

/*Page 2*/
$display2 = "";

/*EDL*/
if ($imgEDL != "") {
    $display2 .= "<h3>Etat des lieux du véhicule</h3>";
    $display2 .= "<br>";
    $display2 .= '<img src="'.$imgEDL.'" alt="edl" width="500" height="400" style="text-align:center"/>';
}

$display2 .= "<br>";
$display2 .= "<br>";
$display2 .= "<br>";
$display2 .= "<br>";

$display2 .= "<p>Fait à Saint Denis le ".$today.",</p>";
$display2 .= "<br>";

/*signature*/
$display2 .= '<img src="'.$imgSignature.'" alt="sign" width="300" height="100" style="text-align:right"/>';


/*Partie PDF et envoi par mail*/
require("TCPDF/tcpdf.php");

$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8'/*'windows-1252'*/, false);

$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
$pdf->AddPage();
$pdf->writeHTML($display, true, false, true, false, '');
$pdf->AddPage();
$pdf->writeHTML($display2, true, false, true, false, '');

/*Partie envoi par mail*/
$mail = new PHPMailer();
try {
    //Server settings
    $mail->SMTPDebug = 0;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com'; 					 // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'mobisoft974@gmail.com';                 // SMTP username
    $mail->Password = 'mobility974';                           // SMTP password
    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 465;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('noreply@idocars.com', 'Idocars');
    /*$mail->addAddress('joe@example.net', 'Joe User');     // Add a recipient*/
    $mail->addAddress('david.calmel@mobisoft.re');               // Name is optional
    /*$mail->addReplyTo('info@example.com', 'Information');*/
    $mail->addCC('c2s.idocars@gmail.com');
    $mail->addCC($client_email);
    /*$mail->addBCC('bcc@example.com');*/

    //Attachments
    /*$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name*/
    $doc = $pdf->Output('doc.pdf','S');
	$mail->AddStringAttachment($doc, 'doc.pdf', 'base64', 'application/pdf');
    $mail->AddAttachment($_SERVER['DOCUMENT_ROOT'].'/sites_clients/idocars/mo_services/pdf/cgv_idocars.pdf', $name = 'CGV.pdf',  $encoding = 'base64', $type = 'application/pdf');

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Recapitulatif de commande - '.$plaque;
    $body = "Cher(e) Client(e) l'ensemble de l'IDOéquipe vous remercie d'avoir choisi IDOCARS pour l'entretien esthétique de votre auto.<br><br>";
    $body .= "Trouvez ci-joint nos CGV, le détail de votre commande ainsi qu'un état des lieux de votre auto lors de sa prise en charge.<br><br>";
    $body .= "Un message vous sera envoyé lorsque que votre commande sera prête.<br><br>";
    $body .= "REGLEMENTS:<br><br>";
    $body .= "-Pour tout règlement par chèque veuillez vous munir de votre pièce d'identité.<br><br>";
    $body .= "-Si vous souhaitez régler par CB merci d'en informer le livreur afin de vérifier la disponibilité de l'appareil TPE.<br><br>";
    $body .= "-En cas de règlement en espèces veuillez prévoir l'appoint.<br><br>";
    $mail->Body = $body;

    $body2 = "Cher(e) Client(e) l'ensemble de l'IDOéquipe vous remercie d'avoir choisi IDOCARS pour l'entretien esthétique de votre auto.\n";
    $body2 .= "Trouvez ci-joint nos CGV, le détail de votre commande ainsi qu'un état des lieux de votre auto lors de sa prise en charge.\n";
    $body2 .= "Un message vous sera envoyé lorsque que votre commande sera prête.\n";
    $body2 .= "REGLEMENTS:\n";
    $body2 .= "-Pour tout règlement par chèque veuillez vous munir de votre pièce d'identité.\n";
    $body2 .= "-Si vous souhaitez régler par CB merci d'en informer le livreur afin de vérifier la disponibilité de l'appareil TPE.\n";
    $body2 .= "-En cas de règlement en espèces veuillez prévoir l'appoint.\n";
    $mail->AltBody = $body2;

    $mail->send();
    /*echo 'Message has been sent';*/
    echo 1;
} catch (Exception $e) {
    /*echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;*/
    echo 0;
}



    }else{
        die();
    }
?>