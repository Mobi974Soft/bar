<?php
//http://stackoverflow.com/questions/18382740/cors-not-working-php
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin:{$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:{$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }

    //http://stackoverflow.com/questions/15485354/angular-http-post-to-php-and-undefined
    $postdata = file_get_contents("php://input");
    if (isset($postdata)) {

        $request = json_decode($postdata);
        $clientId = $request->post_clientId;

        require_once ('../wp-config.php');
        //require_once(ABSPATH . 'wp-admin/includes/image.php');
        global $wpdb;

        //avec file_get_contents

        $r = "SELECT * FROM ido_voitures";
        $r .= " WHERE clientId = ".$clientId;

        $q = $wpdb->get_results($r);

        if (count($q)>0) {
            /*creation du json*/
            $json = '[';
            foreach($q as $car){

                /*partie preparation des donnees*/
                $donnees = array(
                    "id" => $car->id,
                    "plaqueId" => $car->plaqueId,
                    "clientId" => $car->clientId,
                    "marque" => $car->marque,
                    "modele" => $car->modele,
                    "type" => $car->type
                );

                /*encode json*/
                $json .= json_encode($donnees);
                $json .= ",";
        }

        $json = substr($json,0,strlen($json)-1);
        $json .= ']';

        echo $json;
        }else{
            echo 0;
        }

    }else{
        die();
    }
?>