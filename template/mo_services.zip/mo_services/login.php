<?php
	//http://stackoverflow.com/questions/18382740/cors-not-working-php
	if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin:{$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:{$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }

    //http://stackoverflow.com/questions/15485354/angular-http-post-to-php-and-undefined
    $postdata = file_get_contents("php://input");
	if (isset($postdata)) {
		$request = json_decode($postdata);
		$username = $request->username;
		$userpass = $request->usermdp;

		//connexion DB
		include_once ('../wp-config.php');
		include_once ('../wp-includes/wp-db.php');
		include_once ('../wp-includes/class-phpass.php');
		global $wpdb;

		$req = "SELECT ID, user_pass FROM ido_users WHERE user_login LIKE '".$username."'";
		$res = $wpdb->get_results($req);
		//comparaison pass

		if(count($res)>0){
			//hash sera le mdp crypte en bdd correspondant a l'user
			//$hash = $user->user_pass;
			$hash = $res[0]->user_pass;
			$wp_hasher = new PasswordHash(8, TRUE);
			$check = $wp_hasher->CheckPassword($userpass, $hash);

			if ($check) {
				echo 1;
				//echo $res[0]->ID;
			}
			else {
				echo 0;
			}
		}
	}
	else {
		echo "Echec de connexion";
	}
?>