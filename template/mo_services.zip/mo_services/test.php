<?php


require_once ('../wp-config.php');
global $wpdb;

$lavageId = 170;

/*Partie recuperation des donnees*/
$typesLavage = array();
$optionsLavage = array();
$plaque = "";
$type = "";
$tmpTL = array();
$tmpOL = array();
$tmpTotal = array();
$total = 0;
$today = Date("d/m/Y");

$r = "SELECT a.typesLavage as typesLavage, a.optionsLavage as optionsLavage, b.plaqueId as plaqueId, b.type as type FROM ido_lavages as a JOIN ido_voitures as b ON (a.voitureId = b.id) WHERE a.id = ".$lavageId;
$q = $wpdb->get_results($r);

if (count($q)>0) {
	foreach($q as $lavage){
		$typesLavage = explode(",", $lavage->typesLavage);
		$optionsLavage = explode(",", $lavage->optionsLavage);
		$plaque = $lavage->plaqueId;
		$type = $lavage->type;
	}
}


/*Recuperer la liste des prix*/
$recup = json_decode(file_get_contents("jsons/typesLavage.json"));

foreach ($recup as $value) {
	if ($value->type == $type OR $value->type == "ALL" ) {
		for ($i=0; $i < count($typesLavage); $i++) {
			if ($typesLavage[$i] == $value->text) {
				array_push($tmpTL,$value);
			}
		}
	}
    if ($value->type == "") {
        for ($i=0; $i < count($optionsLavage); $i++) { 
            if ($optionsLavage[$i] == $value->text) {
                array_push($tmpOL,$value);
            }
        }
    }
}

$tmpTotal = array_merge($tmpTL,$tmpOL);
foreach ($tmpTotal as $value) {
    $total += $value->prix;
}

/*design de l'email*/
$display = "";

/*header*/
$display .= '<img src="img/logo.png" alt="logo" width="100" height="100"/>';
$display .= '<h2 style="text-align: center;">Recapitulatif de commande</h2>';
$display .= '<h3 style="text-align: center;">'.$plaque.'</h3>';

$display .= "<br>";
$display .= "<br>";
$display .= "<br>";
$display .= "<br>";

/*body*/
$display .= "<br>";
$display .= "<h3>Types de lavages</h3>";
$display .= "<table>";
foreach ($tmpTL as $value) {
	$display .= "<tr>";
		$display .= "<td>";
		$display .= $value->text;
		$display .= "</td>";
		$display .= "<td>";
			$display .= $value->prix." &euro;";
		$display .= "</td>";
	$display .= "</tr>";	
}
$display .= "</table>";
$display .= "<h3>Options de lavages</h3>";
$display .= "<table>";
foreach ($tmpOL as $value) {
    $display .= "<tr>";
        $display .= "<td>";
        $display .= $value->text;
        $display .= "</td>";
        $display .= "<td>";
            $display .= $value->prix." &euro;";
        $display .= "</td>";
    $display .= "</tr>";    
}
$display .= "</table>";
$display .= "<h3>Total à payer</h3>";
$display .= "<table>";
$display .= "<tr>";
$display .= "<td>";
$display .= "</td>";
$display .= "<td>";
$display .= $total." &euro;";
$display .= "</td>";
$display .= "</tr>";
$display .= "</table>";

$display .= "<br>";
$display .= "<br>";
$display .= "<br>";
$display .= "<br>";

/*footer*/
$display .= "Fait à Saint Denis le ".$today.",";
/*signature*/
/*$display .= '<img src="'.$imgSignature.'" alt="logo" width="300" height="100" style="text-align:right"/>';*/


/*Partie PDF et envoi par mail*/
require("TCPDF/tcpdf.php");

$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
$pdf->AddPage();
$pdf->writeHTML($display, true, false, true, false, '');

/*Partie envoi par mail*/
$mail = new PHPMailer();
try {
    //Server settings
    $mail->SMTPDebug = 0;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com'; 					 // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'mobisoft974@gmail.com';                 // SMTP username
    $mail->Password = 'mobility974';                           // SMTP password
    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 465;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('noreply@idocars.com', 'Idocars');
    /*$mail->addAddress('joe@example.net', 'Joe User');     // Add a recipient*/
    $mail->addAddress('stephane.chane-hune@mobisoft.re');               // Name is optional
    /*$mail->addReplyTo('info@example.com', 'Information');*/
    /*$mail->addCC('cc@example.com');*/
    /*$mail->addBCC('bcc@example.com');*/

    //Attachments
    /*$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name*/
    $doc = $pdf->Output('S');
	$mail->AddStringAttachment($doc, 'doc.pdf', 'base64', 'application/pdf');
    $mail->AddAttachment($_SERVER['DOCUMENT_ROOT'].'/sites_clients/idocars/mo_services/pdf/cgv_idocars.pdf', $name = 'CGV.pdf',  $encoding = 'base64', $type = 'application/pdf');

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Here is the subject';
    $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    /*echo 'Message has been sent';*/
    echo 1;
} catch (Exception $e) {
    /*echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;*/
    echo 0;
}

?>