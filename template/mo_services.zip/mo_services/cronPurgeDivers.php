<?php

require_once ('/var/www/html/sites_clients/idocars/wp-config.php');
global $wpdb;

// Récuperation de l'id du client à nettoyer
$q = "SELECT * FROM ido_clients WHERE nom = 'Divers'";
$r_client = $wpdb->get_row($q);
$client_id = $r_client->id;

// Récupération de ses voitures
$q = "SELECT * FROM ido_voitures WHERE clientId = ".$client_id;
$r_voitures = $wpdb->get_results($q);

// Pour chaque voiture
foreach ($r_voitures as $voiture) {
	$voiture_id = $voiture->id;
	
	// Recuperation des etats des lieux
	$q = "SELECT imgUrl FROM ido_etat_des_lieux WHERE voitureId = ".$voiture_id;
	$r_etat_des_lieux = $wpdb->get_results($q);
	// Pour chaque etat des lieux
	foreach ($r_etat_des_lieux as $edl) {
		$imgUrl = $edl->imgUrl;
		// Suppression de l'image d'etat des lieux
		$urlBase = "/var/www/html/sites_clients/idocars";
		$urlFinal = $urlBase.$imgUrl;
		unlink($urlFinal);
	}

	// Suppression des etats des lieux
	$wpdb->delete('ido_etat_des_lieux', array('voitureId' => $voiture_id));

	// Suppression des lavages
	$wpdb->delete('ido_lavages', array('voitureId' => $voiture_id));
}

// Suppression des voitures
$wpdb->delete('ido_voitures', array('clientId' => $client_id));

?>