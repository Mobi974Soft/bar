<?php 
set_time_limit(0);
ini_set('memory_limit', '512M');
require_once ('../wp-config.php');
global $wpdb;

/* DATEDIFF(date de maintenant,date de modification du post) retournera la difference de jour entre les 2 dates
 * ICI 240 soit environs 8 mois
 * on limite a 200 car probleme d'allocation memoire
 * donc a relancer tant que nb = 0
*/
$q = "SELECT lavageId, imgUrl FROM ido_etat_des_lieux WHERE DATEDIFF(NOW(),quand) > 240 ORDER BY id";
$r = $wpdb->get_results($q);

$lavageId = array();
$imgUrl = array();
echo "nb = ".count($r)."<br>";
foreach ($r as $info) {
	
	$id = $info->lavageId;
	$url = $info->imgUrl;
	echo "<br>".$id;
	array_push($lavageId,$id);
	array_push($imgUrl,$url);

}

$tmp = implode(",", $lavageId);

//print_r($imgUrl);


//suppression des lavages
$q = "DELETE FROM ido_lavages WHERE id IN (".$tmp.")";
$r = $wpdb->get_results($q);
//suppression des etats des lieux
$q = "DELETE FROM ido_etat_des_lieux WHERE DATEDIFF(NOW(),quand) > 240 ORDER BY id";
$r = $wpdb->get_results($q);

//suppression des images sur le serveur
if(count($imgUrl)){
$chemin = "/var/www/html/sites_clients/idocars";
foreach ($imgUrl as $u) {
	$img = $chemin.$u;
	echo  "<br>".$img;
	$test = unlink($img);
	echo  "<br>".$test."<br>";
}
}

?>