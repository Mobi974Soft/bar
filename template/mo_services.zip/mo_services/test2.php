<?php
/*echo $_SERVER["DOCUMENT_ROOT"];*/
$recup = file_get_contents("jsons/typesLavage.json");
echo $recup;
?>